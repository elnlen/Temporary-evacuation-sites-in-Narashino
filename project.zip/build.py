import json
import os
from html import escape

# JSONを読む
with open("03_hinan.json", encoding="utf-8") as f:
    places = json.load(f)

# 出力先
os.makedirs("place", exist_ok=True)

for place in places:
    title = escape(place["施設名称"])
    address = escape(place["住所"])
    phone = escape(place.get("電話番号") or "なし")
    number = place["項番"]

    html = f"""<!doctype html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>{title} | 習志野市 一時避難場所</title>

<meta name="description"
      content="{title}の所在地・電話番号などを掲載しています。">

<link rel="stylesheet" href="../style.css">
</head>

<body>

<header>
<a href="../index.html">← 一覧へ戻る</a>
</header>

<main>

<h1>{title}</h1>

<h2>住所</h2>
<p>{address}</p>

<h2>電話番号</h2>
<p>{phone}</p>

<p>
<a href="https://www.google.com/maps/search/?api=1&query={address}">
Google Mapsで見る
</a>
</p>

</main>

</body>
</html>
"""

    with open(f"place/{number}.html", "w", encoding="utf-8") as f:
        f.write(html)

print(f"{len(places)}ページ生成しました。")
